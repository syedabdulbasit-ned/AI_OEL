from django.contrib import admin
from .models import BinaryImage

# Register your models here.
admin.site.register(BinaryImage)
